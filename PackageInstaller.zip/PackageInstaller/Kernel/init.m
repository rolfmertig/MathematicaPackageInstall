(* Mathematica Init File *)

Get[ "Installer`Installer`"]